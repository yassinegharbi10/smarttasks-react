// ============================================================
// CONTEXT : AuthContext
// Gestion globale de l'état d'authentification
// ============================================================

import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../models/User';

// Création du contexte
const AuthContext = createContext(null);

/**
 * Hook personnalisé pour utiliser le contexte d'auth
 */
export function useAuth() {
  return useContext(AuthContext);
}

/**
 * Provider qui enveloppe l'application et partage l'état d'auth
 */
export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading]         = useState(true);

  // Vérifier la session au chargement
  useEffect(() => {
    const user = User.getCurrentUser();
    setCurrentUser(user);
    setLoading(false);
  }, []);

  // Fonction de connexion
  const login = (email, password) => {
    const user = User.login(email, password);
    if (user) {
      setCurrentUser(user);
      return true;
    }
    return false;
  };

  // Fonction de déconnexion
  const logout = () => {
    User.logout();
    setCurrentUser(null);
  };

  // Fonction d'inscription
  const register = (nom, email, password) => {
    const user = new User(nom, email, password);
    return user.register();
  };

  const value = { currentUser, login, logout, register, loading };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}
