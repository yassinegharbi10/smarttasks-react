// ============================================================
// MODÈLE POO : Classe User
// Applique les principes d'encapsulation et d'abstraction
// ============================================================

import { v4 as uuidv4 } from 'uuid';

export class User {
  // Attributs privés (encapsulation)
  #id;
  #nom;
  #email;
  #password;

  constructor(nom, email, password, id = uuidv4()) {
    this.#id      = id;
    this.#nom     = nom;
    this.#email   = email;
    this.#password = password;
  }

  // ─── Getters (accès contrôlé aux attributs privés) ───
  get id()       { return this.#id; }
  get nom()      { return this.#nom; }
  get email()    { return this.#email; }
  get password() { return this.#password; }

  // ─── Méthode register ────────────────────────────────
  /**
   * Enregistre l'utilisateur dans le LocalStorage.
   * @returns {boolean} true si succès, false si email déjà existant
   */
  register() {
    const users = User.getAllUsers();

    // Vérifier si l'email est déjà utilisé
    const exists = users.find(u => u.email === this.#email);
    if (exists) return false;

    // Ajouter l'utilisateur
    users.push(this.toJSON());
    localStorage.setItem('smarttasks_users', JSON.stringify(users));
    return true;
  }

  // ─── Méthode login (statique) ─────────────────────────
  /**
   * Vérifie les credentials et connecte l'utilisateur.
   * @param {string} email
   * @param {string} password
   * @returns {User|null} l'utilisateur connecté ou null
   */
  static login(email, password) {
    const users = User.getAllUsers();
    const data  = users.find(u => u.email === email && u.password === password);
    if (!data) return null;

    const user = new User(data.nom, data.email, data.password, data.id);
    // Sauvegarder la session
    localStorage.setItem('smarttasks_session', JSON.stringify(user.toJSON()));
    return user;
  }

  // ─── Méthode logout (statique) ────────────────────────
  /**
   * Déconnecte l'utilisateur en supprimant la session.
   */
  static logout() {
    localStorage.removeItem('smarttasks_session');
  }

  // ─── Méthode utilitaire : récupérer tous les users ───
  static getAllUsers() {
    const data = localStorage.getItem('smarttasks_users');
    return data ? JSON.parse(data) : [];
  }

  // ─── Méthode utilitaire : récupérer la session ───────
  static getCurrentUser() {
    const data = localStorage.getItem('smarttasks_session');
    if (!data) return null;
    const u = JSON.parse(data);
    return new User(u.nom, u.email, u.password, u.id);
  }

  // ─── Sérialisation (pour le stockage) ────────────────
  toJSON() {
    return {
      id:       this.#id,
      nom:      this.#nom,
      email:    this.#email,
      password: this.#password,
    };
  }
}
