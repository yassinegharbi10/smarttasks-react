// ============================================================
// MODÈLE POO : Classe Task
// Applique l'encapsulation, les getters/setters, et les méthodes métier
// ============================================================

import { v4 as uuidv4 } from 'uuid';

export class Task {
  // Attributs privés
  #id;
  #title;
  #description;
  #status;   // 'pending' | 'completed'
  #date;
  #userId;   // propriétaire de la tâche

  constructor({ title, description, status = 'pending', date, userId, id = uuidv4() }) {
    this.#id          = id;
    this.#title       = title;
    this.#description = description;
    this.#status      = status;
    this.#date        = date || new Date().toISOString().split('T')[0];
    this.#userId      = userId;
  }

  // ─── Getters ─────────────────────────────────────────
  get id()          { return this.#id; }
  get title()       { return this.#title; }
  get description() { return this.#description; }
  get status()      { return this.#status; }
  get date()        { return this.#date; }
  get userId()      { return this.#userId; }
  get isCompleted() { return this.#status === 'completed'; }

  // ─── Setters (validation incluse) ────────────────────
  set title(val) {
    if (!val || val.trim() === '') throw new Error('Le titre est obligatoire');
    this.#title = val.trim();
  }
  set description(val) { this.#description = val; }
  set date(val)        { this.#date = val; }

  // ─── Méthode : Ajouter la tâche ──────────────────────
  /**
   * Sauvegarde la tâche dans le LocalStorage.
   */
  addTask() {
    const tasks = Task.getAllTasksRaw();
    tasks.push(this.toJSON());
    localStorage.setItem('smarttasks_tasks', JSON.stringify(tasks));
    return this;
  }

  // ─── Méthode : Mettre à jour la tâche ────────────────
  /**
   * Met à jour les informations de la tâche.
   * @param {{ title, description, date, status }} updates
   */
  updateTask(updates) {
    if (updates.title)       this.#title       = updates.title;
    if (updates.description !== undefined) this.#description = updates.description;
    if (updates.date)        this.#date        = updates.date;
    if (updates.status)      this.#status      = updates.status;

    const tasks = Task.getAllTasksRaw().map(t =>
      t.id === this.#id ? this.toJSON() : t
    );
    localStorage.setItem('smarttasks_tasks', JSON.stringify(tasks));
    return this;
  }

  // ─── Méthode : Supprimer la tâche ────────────────────
  /**
   * Supprime la tâche du LocalStorage.
   */
  deleteTask() {
    const tasks = Task.getAllTasksRaw().filter(t => t.id !== this.#id);
    localStorage.setItem('smarttasks_tasks', JSON.stringify(tasks));
  }

  // ─── Méthode : Marquer comme terminée ────────────────
  /**
   * Bascule le statut entre 'pending' et 'completed'.
   */
  completeTask() {
    this.#status = this.#status === 'completed' ? 'pending' : 'completed';
    const tasks = Task.getAllTasksRaw().map(t =>
      t.id === this.#id ? this.toJSON() : t
    );
    localStorage.setItem('smarttasks_tasks', JSON.stringify(tasks));
    return this;
  }

  // ─── Méthodes statiques ───────────────────────────────
  /**
   * Retourne toutes les tâches (données brutes).
   */
  static getAllTasksRaw() {
    const data = localStorage.getItem('smarttasks_tasks');
    return data ? JSON.parse(data) : [];
  }

  /**
   * Retourne les tâches d'un utilisateur sous forme d'instances Task.
   * @param {string} userId
   * @returns {Task[]}
   */
  static getTasksByUser(userId) {
    return Task.getAllTasksRaw()
      .filter(t => t.userId === userId)
      .map(t => new Task(t));
  }

  /**
   * Trouve une tâche par son ID.
   * @param {string} id
   * @returns {Task|null}
   */
  static findById(id) {
    const data = Task.getAllTasksRaw().find(t => t.id === id);
    return data ? new Task(data) : null;
  }

  // ─── Sérialisation ────────────────────────────────────
  toJSON() {
    return {
      id:          this.#id,
      title:       this.#title,
      description: this.#description,
      status:      this.#status,
      date:        this.#date,
      userId:      this.#userId,
    };
  }
}
