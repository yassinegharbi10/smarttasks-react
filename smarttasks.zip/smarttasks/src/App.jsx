// ============================================================
// APP.JSX — Routeur principal de SmartTasks
// ============================================================

import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';

// Contextes
import { AuthProvider }  from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { ToastProvider } from './services/ToastService';

// Layout
import Navbar      from './components/Navbar';
import PrivateRoute from './routes/PrivateRoute';

// Pages
import Login     from './pages/Login';
import Register  from './pages/Register';
import Dashboard from './pages/Dashboard';
import AddTask   from './pages/AddTask';
import EditTask  from './pages/EditTask';

export default function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <AuthProvider>
          <ToastProvider>
            <Navbar />
            <div className="main-layout">
              <div className="page-wrapper">
                <Routes>
                  {/* Redirection racine */}
                  <Route path="/" element={<Navigate to="/login" replace />} />

                  {/* Pages publiques */}
                  <Route path="/login"    element={<Login />} />
                  <Route path="/register" element={<Register />} />

                  {/* Pages protégées (nécessitent une connexion) */}
                  <Route path="/dashboard" element={
                    <PrivateRoute><Dashboard /></PrivateRoute>
                  } />
                  <Route path="/add-task" element={
                    <PrivateRoute><AddTask /></PrivateRoute>
                  } />
                  <Route path="/edit-task/:id" element={
                    <PrivateRoute><EditTask /></PrivateRoute>
                  } />

                  {/* Fallback */}
                  <Route path="*" element={<Navigate to="/dashboard" replace />} />
                </Routes>
              </div>
            </div>
          </ToastProvider>
        </AuthProvider>
      </ThemeProvider>
    </BrowserRouter>
  );
}
