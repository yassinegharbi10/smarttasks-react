// ============================================================
// COMPOSANT : StatsCard — Carte de statistique du Dashboard
// ============================================================

import React from 'react';

export default function StatsCard({ label, value, icon, color }) {
  return (
    <div className={`stats-card stats-${color}`}>
      <div className="stats-icon">{icon}</div>
      <div className="stats-body">
        <div className="stats-value">{value}</div>
        <div className="stats-label">{label}</div>
      </div>
    </div>
  );
}
