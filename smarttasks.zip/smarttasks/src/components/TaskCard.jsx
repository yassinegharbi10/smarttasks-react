// ============================================================
// COMPOSANT : TaskCard — Affiche une tâche avec actions CRUD
// ============================================================

import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Task } from '../models/Task';
import { useToast } from '../services/ToastService';

export default function TaskCard({ task, onRefresh }) {
  const navigate = useNavigate();
  const toast    = useToast();

  // Instancier un objet Task POO depuis les données
  const taskObj = new Task(task);

  // ─── Marquer comme terminée / en attente ─────────────
  const handleToggleComplete = () => {
    taskObj.completeTask();
    const msg = taskObj.isCompleted
      ? `"${taskObj.title}" marquée comme terminée ✓`
      : `"${taskObj.title}" remise en attente`;
    toast.success(msg);
    onRefresh();
  };

  // ─── Supprimer la tâche ───────────────────────────────
  const handleDelete = () => {
    if (window.confirm(`Supprimer la tâche "${taskObj.title}" ?`)) {
      taskObj.deleteTask();
      toast.error(`Tâche "${taskObj.title}" supprimée.`);
      onRefresh();
    }
  };

  // ─── Modifier la tâche ────────────────────────────────
  const handleEdit = () => {
    navigate(`/edit-task/${taskObj.id}`);
  };

  return (
    <div className={`task-card ${taskObj.isCompleted ? 'task-completed' : ''}`}>
      {/* Indicateur de statut */}
      <div className={`task-status-bar ${taskObj.isCompleted ? 'bar-done' : 'bar-pending'}`} />

      <div className="task-content">
        <div className="task-header">
          <h3 className="task-title">{taskObj.title}</h3>
          <span className={`badge ${taskObj.isCompleted ? 'badge-success' : 'badge-warning'}`}>
            {taskObj.isCompleted ? 'Terminée' : 'En attente'}
          </span>
        </div>

        {taskObj.description && (
          <p className="task-desc">{taskObj.description}</p>
        )}

        <div className="task-meta">
          <span className="task-date">📅 {taskObj.date}</span>
        </div>
      </div>

      {/* Actions */}
      <div className="task-actions">
        <button
          className={`btn-action ${taskObj.isCompleted ? 'btn-undo' : 'btn-complete'}`}
          onClick={handleToggleComplete}
          title={taskObj.isCompleted ? 'Remettre en attente' : 'Marquer terminée'}
        >
          {taskObj.isCompleted ? '↩' : '✓'}
        </button>
        <button
          className="btn-action btn-edit"
          onClick={handleEdit}
          title="Modifier"
        >
          ✎
        </button>
        <button
          className="btn-action btn-delete"
          onClick={handleDelete}
          title="Supprimer"
        >
          ✕
        </button>
      </div>
    </div>
  );
}
