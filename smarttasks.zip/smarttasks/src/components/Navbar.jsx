// ============================================================
// COMPOSANT : Navbar
// ============================================================

import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { useToast } from '../services/ToastService';

export default function Navbar() {
  const { currentUser, logout } = useAuth();
  const { darkMode, toggleTheme } = useTheme();
  const toast    = useToast();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    toast.info('Déconnexion réussie. À bientôt !');
    navigate('/login');
  };

  return (
    <nav className="navbar">
      <div className="navbar-brand">
        <Link to="/dashboard" className="brand-logo">
          <span className="brand-icon">⚡</span>
          SmartTasks
        </Link>
      </div>

      {currentUser && (
        <div className="navbar-actions">
          {/* Bouton mode sombre */}
          <button
            className="btn-icon"
            onClick={toggleTheme}
            title={darkMode ? 'Mode clair' : 'Mode sombre'}
          >
            {darkMode ? '☀️' : '🌙'}
          </button>

          {/* Nom utilisateur */}
          <span className="user-badge">
            <span className="user-avatar">
              {currentUser.nom.charAt(0).toUpperCase()}
            </span>
            {currentUser.nom}
          </span>

          {/* Déconnexion */}
          <button className="btn btn-outline-sm" onClick={handleLogout}>
            Déconnexion
          </button>
        </div>
      )}
    </nav>
  );
}
