// ============================================================
// PAGE : Register — Inscription d'un nouvel utilisateur
// ============================================================

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../services/ToastService';

export default function Register() {
  const [nom,      setNom]      = useState('');
  const [email,    setEmail]    = useState('');
  const [password, setPassword] = useState('');
  const [errors,   setErrors]   = useState({});
  const [loading,  setLoading]  = useState(false);

  const { register } = useAuth();
  const toast        = useToast();
  const navigate     = useNavigate();

  // ─── Validation ───────────────────────────────────────
  const validate = () => {
    const errs = {};
    if (!nom.trim())  errs.nom = 'Le nom est obligatoire.';
    if (!email.trim()) errs.email = "L'email est obligatoire.";
    else if (!/\S+@\S+\.\S+/.test(email)) errs.email = 'Email invalide.';
    if (!password)    errs.password = 'Le mot de passe est obligatoire.';
    else if (password.length < 6) errs.password = 'Minimum 6 caractères.';
    return errs;
  };

  // ─── Soumission ───────────────────────────────────────
  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }

    setLoading(true);
    setTimeout(() => {
      const success = register(nom, email, password);
      setLoading(false);
      if (success) {
        toast.success('Compte créé avec succès ! Connectez-vous.');
        navigate('/login');
      } else {
        setErrors({ email: 'Cet email est déjà utilisé.' });
        toast.error('Email déjà utilisé.');
      }
    }, 600);
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-header">
          <div className="auth-logo">⚡</div>
          <h1 className="auth-title">SmartTasks</h1>
          <p className="auth-subtitle">Créez votre compte gratuitement</p>
        </div>

        <form onSubmit={handleSubmit} className="auth-form" noValidate>
          {/* Nom */}
          <div className="form-group">
            <label className="form-label">Nom complet</label>
            <input
              type="text"
              className={`form-input ${errors.nom ? 'input-error' : ''}`}
              placeholder="Votre nom"
              value={nom}
              onChange={e => { setNom(e.target.value); setErrors({}); }}
            />
            {errors.nom && <span className="error-msg">{errors.nom}</span>}
          </div>

          {/* Email */}
          <div className="form-group">
            <label className="form-label">Email</label>
            <input
              type="email"
              className={`form-input ${errors.email ? 'input-error' : ''}`}
              placeholder="vous@exemple.com"
              value={email}
              onChange={e => { setEmail(e.target.value); setErrors({}); }}
            />
            {errors.email && <span className="error-msg">{errors.email}</span>}
          </div>

          {/* Mot de passe */}
          <div className="form-group">
            <label className="form-label">Mot de passe</label>
            <input
              type="password"
              className={`form-input ${errors.password ? 'input-error' : ''}`}
              placeholder="Minimum 6 caractères"
              value={password}
              onChange={e => { setPassword(e.target.value); setErrors({}); }}
            />
            {errors.password && <span className="error-msg">{errors.password}</span>}
          </div>

          <button type="submit" className="btn btn-primary btn-full" disabled={loading}>
            {loading ? <span className="spinner" /> : "Créer mon compte"}
          </button>
        </form>

        <p className="auth-link">
          Déjà un compte ?{' '}
          <Link to="/login">Se connecter</Link>
        </p>
      </div>
    </div>
  );
}
