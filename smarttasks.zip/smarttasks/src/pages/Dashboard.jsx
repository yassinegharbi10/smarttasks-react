// ============================================================
// PAGE : Dashboard — Tableau de bord principal
// ============================================================

import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Task } from '../models/Task';
import TaskCard from '../components/TaskCard';
import StatsCard from '../components/StatsCard';

export default function Dashboard() {
  const { currentUser } = useAuth();

  // ─── État local ───────────────────────────────────────
  const [tasks,       setTasks]       = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filter,      setFilter]      = useState('all'); // 'all' | 'pending' | 'completed'

  // ─── Charger les tâches de l'utilisateur ─────────────
  const loadTasks = useCallback(() => {
    const userTasks = Task.getTasksByUser(currentUser.id);
    setTasks(userTasks.map(t => t.toJSON())); // Convertir en objets simples pour le state
  }, [currentUser.id]);

  useEffect(() => {
    loadTasks();
  }, [loadTasks]);

  // ─── Statistiques ─────────────────────────────────────
  const total     = tasks.length;
  const completed = tasks.filter(t => t.status === 'completed').length;
  const pending   = tasks.filter(t => t.status === 'pending').length;

  // ─── Filtrage + Recherche ─────────────────────────────
  const filteredTasks = tasks
    .filter(t => filter === 'all' || t.status === filter)
    .filter(t =>
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (t.description || '').toLowerCase().includes(searchQuery.toLowerCase())
    );

  return (
    <div className="dashboard-page">
      {/* En-tête du dashboard */}
      <div className="dashboard-header">
        <div>
          <h1 className="page-title">
            Bonjour, <span className="highlight">{currentUser.nom}</span> 👋
          </h1>
          <p className="page-subtitle">Gérez vos tâches intelligemment</p>
        </div>
        <Link to="/add-task" className="btn btn-primary">
          <span>+</span> Nouvelle tâche
        </Link>
      </div>

      {/* Cartes de statistiques */}
      <div className="stats-grid">
        <StatsCard
          label="Total des tâches"
          value={total}
          icon="📋"
          color="blue"
        />
        <StatsCard
          label="Terminées"
          value={completed}
          icon="✅"
          color="green"
        />
        <StatsCard
          label="En attente"
          value={pending}
          icon="⏳"
          color="orange"
        />
        <StatsCard
          label="Progression"
          value={total > 0 ? `${Math.round((completed / total) * 100)}%` : '0%'}
          icon="📈"
          color="purple"
        />
      </div>

      {/* Barre de recherche + filtres */}
      <div className="tasks-toolbar">
        <div className="search-wrapper">
          <span className="search-icon">🔍</span>
          <input
            type="text"
            className="search-input"
            placeholder="Rechercher une tâche..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button className="search-clear" onClick={() => setSearchQuery('')}>✕</button>
          )}
        </div>

        <div className="filter-buttons">
          {[
            { key: 'all',       label: 'Toutes' },
            { key: 'pending',   label: 'En attente' },
            { key: 'completed', label: 'Terminées' },
          ].map(f => (
            <button
              key={f.key}
              className={`filter-btn ${filter === f.key ? 'active' : ''}`}
              onClick={() => setFilter(f.key)}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Liste des tâches */}
      <div className="tasks-section">
        {filteredTasks.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">📭</div>
            <p className="empty-title">
              {searchQuery ? 'Aucune tâche trouvée' : 'Aucune tâche pour le moment'}
            </p>
            <p className="empty-desc">
              {!searchQuery && (
                <Link to="/add-task" className="btn btn-primary">
                  Créer ma première tâche
                </Link>
              )}
            </p>
          </div>
        ) : (
          <div className="tasks-list">
            {filteredTasks.map(task => (
              <TaskCard
                key={task.id}
                task={task}
                onRefresh={loadTasks}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
