// ============================================================
// PAGE : EditTask — Modifier une tâche existante
// ============================================================

import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Task } from '../models/Task';
import { useToast } from '../services/ToastService';

export default function EditTask() {
  const { id }   = useParams(); // Récupère l'ID depuis l'URL
  const navigate = useNavigate();
  const toast    = useToast();

  // ─── État du formulaire ───────────────────────────────
  const [title,       setTitle]       = useState('');
  const [description, setDescription] = useState('');
  const [date,        setDate]        = useState('');
  const [status,      setStatus]      = useState('pending');
  const [errors,      setErrors]      = useState({});
  const [notFound,    setNotFound]    = useState(false);

  // ─── Charger la tâche au montage (useEffect) ─────────
  useEffect(() => {
    // Utilise la méthode statique findById() de la classe Task
    const task = Task.findById(id);
    if (!task) {
      setNotFound(true);
      return;
    }
    setTitle(task.title);
    setDescription(task.description || '');
    setDate(task.date);
    setStatus(task.status);
  }, [id]);

  // ─── Validation ───────────────────────────────────────
  const validate = () => {
    const errs = {};
    if (!title.trim()) errs.title = 'Le titre est obligatoire.';
    if (!date)         errs.date  = 'La date est obligatoire.';
    return errs;
  };

  // ─── Soumission : mise à jour via méthode POO ─────────
  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }

    // Récupérer l'instance et appeler updateTask()
    const task = Task.findById(id);
    task.updateTask({ title: title.trim(), description: description.trim(), date, status });

    toast.success('Tâche mise à jour avec succès !');
    navigate('/dashboard');
  };

  // ─── Tâche introuvable ────────────────────────────────
  if (notFound) {
    return (
      <div className="form-page">
        <div className="form-card" style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '3rem' }}>🔍</div>
          <h2>Tâche introuvable</h2>
          <button className="btn btn-primary" onClick={() => navigate('/dashboard')}>
            Retour au Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="form-page">
      <div className="form-card">
        <div className="form-card-header">
          <h2 className="form-card-title">✎ Modifier la tâche</h2>
          <p className="form-card-subtitle">Mettez à jour les informations</p>
        </div>

        <form onSubmit={handleSubmit} className="task-form" noValidate>
          {/* Titre */}
          <div className="form-group">
            <label className="form-label">Titre *</label>
            <input
              type="text"
              className={`form-input ${errors.title ? 'input-error' : ''}`}
              value={title}
              onChange={e => { setTitle(e.target.value); setErrors({}); }}
            />
            {errors.title && <span className="error-msg">{errors.title}</span>}
          </div>

          {/* Description */}
          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea
              className="form-input form-textarea"
              rows={4}
              value={description}
              onChange={e => setDescription(e.target.value)}
            />
          </div>

          {/* Date */}
          <div className="form-group">
            <label className="form-label">Date *</label>
            <input
              type="date"
              className={`form-input ${errors.date ? 'input-error' : ''}`}
              value={date}
              onChange={e => { setDate(e.target.value); setErrors({}); }}
            />
            {errors.date && <span className="error-msg">{errors.date}</span>}
          </div>

          {/* Statut */}
          <div className="form-group">
            <label className="form-label">Statut</label>
            <select
              className="form-input form-select"
              value={status}
              onChange={e => setStatus(e.target.value)}
            >
              <option value="pending">⏳ En attente</option>
              <option value="completed">✅ Terminée</option>
            </select>
          </div>

          {/* Actions */}
          <div className="form-actions">
            <button
              type="button"
              className="btn btn-ghost"
              onClick={() => navigate('/dashboard')}
            >
              Annuler
            </button>
            <button type="submit" className="btn btn-primary">
              Enregistrer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
