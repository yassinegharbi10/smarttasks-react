// ============================================================
// PAGE : Login — Authentification de l'utilisateur
// ============================================================

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../services/ToastService';

export default function Login() {
  const [email,    setEmail]    = useState('');
  const [password, setPassword] = useState('');
  const [errors,   setErrors]   = useState({});
  const [loading,  setLoading]  = useState(false);

  const { login }  = useAuth();
  const toast      = useToast();
  const navigate   = useNavigate();

  // ─── Validation du formulaire ─────────────────────────
  const validate = () => {
    const errs = {};
    if (!email.trim())    errs.email    = "L'email est obligatoire.";
    else if (!/\S+@\S+\.\S+/.test(email)) errs.email = "Email invalide.";
    if (!password)        errs.password = "Le mot de passe est obligatoire.";
    return errs;
  };

  // ─── Soumission du formulaire ─────────────────────────
  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }

    setLoading(true);
    setTimeout(() => {
      const success = login(email, password);
      setLoading(false);
      if (success) {
        toast.success('Bienvenue ! Connexion réussie 🎉');
        navigate('/dashboard');
      } else {
        setErrors({ global: 'Email ou mot de passe incorrect.' });
        toast.error('Identifiants incorrects.');
      }
    }, 600);
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        {/* En-tête */}
        <div className="auth-header">
          <div className="auth-logo">⚡</div>
          <h1 className="auth-title">SmartTasks</h1>
          <p className="auth-subtitle">Connectez-vous à votre espace</p>
        </div>

        {/* Erreur globale */}
        {errors.global && (
          <div className="alert alert-error">{errors.global}</div>
        )}

        {/* Formulaire */}
        <form onSubmit={handleSubmit} className="auth-form" noValidate>
          {/* Email */}
          <div className="form-group">
            <label className="form-label">Email</label>
            <input
              type="email"
              className={`form-input ${errors.email ? 'input-error' : ''}`}
              placeholder="vous@exemple.com"
              value={email}
              onChange={e => { setEmail(e.target.value); setErrors({}); }}
            />
            {errors.email && <span className="error-msg">{errors.email}</span>}
          </div>

          {/* Mot de passe */}
          <div className="form-group">
            <label className="form-label">Mot de passe</label>
            <input
              type="password"
              className={`form-input ${errors.password ? 'input-error' : ''}`}
              placeholder="••••••••"
              value={password}
              onChange={e => { setPassword(e.target.value); setErrors({}); }}
            />
            {errors.password && <span className="error-msg">{errors.password}</span>}
          </div>

          {/* Bouton */}
          <button type="submit" className="btn btn-primary btn-full" disabled={loading}>
            {loading ? <span className="spinner" /> : 'Se connecter'}
          </button>
        </form>

        {/* Lien inscription */}
        <p className="auth-link">
          Pas encore de compte ?{' '}
          <Link to="/register">S'inscrire</Link>
        </p>
      </div>
    </div>
  );
}
