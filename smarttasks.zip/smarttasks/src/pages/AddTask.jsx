// ============================================================
// PAGE : AddTask — Ajouter une nouvelle tâche
// ============================================================

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Task } from '../models/Task';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../services/ToastService';

export default function AddTask() {
  const { currentUser } = useAuth();
  const toast    = useToast();
  const navigate = useNavigate();

  // ─── État du formulaire ───────────────────────────────
  const [title,       setTitle]       = useState('');
  const [description, setDescription] = useState('');
  const [date,        setDate]        = useState(new Date().toISOString().split('T')[0]);
  const [errors,      setErrors]      = useState({});

  // ─── Validation ───────────────────────────────────────
  const validate = () => {
    const errs = {};
    if (!title.trim()) errs.title = 'Le titre est obligatoire.';
    if (!date)         errs.date  = 'La date est obligatoire.';
    return errs;
  };

  // ─── Soumission : création d'une instance Task (POO) ──
  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }

    // Instanciation de la classe Task (POO)
    const task = new Task({
      title:       title.trim(),
      description: description.trim(),
      date,
      status:  'pending',
      userId:  currentUser.id,
    });

    // Appel de la méthode addTask() (méthode de la classe)
    task.addTask();

    toast.success(`Tâche "${title}" créée avec succès !`);
    navigate('/dashboard');
  };

  return (
    <div className="form-page">
      <div className="form-card">
        <div className="form-card-header">
          <h2 className="form-card-title">➕ Nouvelle tâche</h2>
          <p className="form-card-subtitle">Planifiez votre prochaine action</p>
        </div>

        <form onSubmit={handleSubmit} className="task-form" noValidate>
          {/* Titre */}
          <div className="form-group">
            <label className="form-label">Titre de la tâche *</label>
            <input
              type="text"
              className={`form-input ${errors.title ? 'input-error' : ''}`}
              placeholder="Ex : Préparer la présentation..."
              value={title}
              onChange={e => { setTitle(e.target.value); setErrors({}); }}
            />
            {errors.title && <span className="error-msg">{errors.title}</span>}
          </div>

          {/* Description */}
          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea
              className="form-input form-textarea"
              placeholder="Décrivez votre tâche en détail..."
              rows={4}
              value={description}
              onChange={e => setDescription(e.target.value)}
            />
          </div>

          {/* Date */}
          <div className="form-group">
            <label className="form-label">Date d'échéance *</label>
            <input
              type="date"
              className={`form-input ${errors.date ? 'input-error' : ''}`}
              value={date}
              onChange={e => { setDate(e.target.value); setErrors({}); }}
            />
            {errors.date && <span className="error-msg">{errors.date}</span>}
          </div>

          {/* Actions */}
          <div className="form-actions">
            <button
              type="button"
              className="btn btn-ghost"
              onClick={() => navigate('/dashboard')}
            >
              Annuler
            </button>
            <button type="submit" className="btn btn-primary">
              Créer la tâche
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
