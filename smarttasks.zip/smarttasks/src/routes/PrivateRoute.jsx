// ============================================================
// ROUTES : PrivateRoute
// Protège les pages accessibles uniquement après connexion
// ============================================================

import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

/**
 * Si l'utilisateur n'est pas connecté → redirige vers /login
 */
export default function PrivateRoute({ children }) {
  const { currentUser } = useAuth();
  return currentUser ? children : <Navigate to="/login" replace />;
}
